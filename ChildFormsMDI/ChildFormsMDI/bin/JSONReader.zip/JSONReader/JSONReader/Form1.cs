﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace JSONReader
{
    public partial class Form1 : Form
    {
        Presenter presenter;
        XmlNode node;
        public Form1()
        {
            InitializeComponent(); 
            presenter = new Presenter(this.NodeTree);
            presenter.Populate();
        }
        
        private void NodeTree_AfterSelect(object sender, TreeViewEventArgs e)
        {
            node = (XmlNode)NodeTree.SelectedNode.Tag;
            NameBox.Text = NodeTree.SelectedNode.Text;
            if (node == null)
                return;
            if (node.InnerText == "")
            {
                ValueBox.Enabled = true;
                ValueBox.Text = "";
                return;
            }
            if (node.FirstChild.NodeType == XmlNodeType.Text)
            {
                ValueBox.Enabled = true;
                ValueBox.Text = node.FirstChild.Value;
            }
            else
            {
                ValueBox.Enabled = false;
                ValueBox.Text = "";
            }
        }

        private void NameBox_TextChanged(object sender, EventArgs e)
        {
            NodeTree.SelectedNode.Text = NameBox.Text;

            string innerXml = node.ParentNode.InnerXml;
            innerXml = innerXml.Replace(node.Name, NameBox.Text);
            node.ParentNode.InnerXml = innerXml;
        }

        private void ValueBox_TextChanged(object sender, EventArgs e)
        {
            if (node.InnerText == "")
            {
                node.InnerText = ValueBox.Text;
                return;
            }
            if (node.FirstChild.NodeType == XmlNodeType.Text)
                node.InnerText = ValueBox.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            presenter.Save();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            XmlElement elem = presenter.root.CreateElement("NewNode");

            TreeNode curNodeTree = new TreeNode(elem.Name);
            
            curNodeTree.Tag = elem;
            NodeTree.SelectedNode.Parent.Nodes.Add(curNodeTree);
            elem.InnerText = "";

            node.ParentNode.PrependChild(elem);
            NodeTree.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            NodeTree.SelectedNode.Remove();
            node.ParentNode.RemoveChild(node);

        }
    }
}
