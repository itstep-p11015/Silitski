﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.IO;
using System.Xml;

namespace JSONReader
{
    class Presenter
    {
        TreeView nodeTree;
        public XmlDocument root;
        XmlElement doc;
        public Presenter(TreeView nodeTree)
        {
            //StreamReader reader = new StreamReader("JSON_Read.txt");
            StreamReader reader = new StreamReader("JSON_Write.txt");
            string json = reader.ReadToEnd();
            root = JsonConvert.DeserializeXmlNode(json);
            doc = root["root"];
            this.nodeTree = nodeTree;
            reader.Close();
        }

        public void Populate()
        {
            TreeNode NodeTree = new TreeNode(doc.Name);
            setNodes(doc, NodeTree);
            nodeTree.Nodes.Add(NodeTree);
        }

        private void setNodes(XmlNode node, TreeNode par)
        {
            if (node.HasChildNodes)
            {
                foreach (XmlNode child in node)
                {
                    TreeNode curNode = new TreeNode(child.Name);
                    if (child.NodeType == XmlNodeType.Element)
                    {
                        setNodes(child, curNode);
                        curNode.Tag = child;
                        par.Nodes.Add(curNode);
                    }
                }
            }
            else
                return;
        }
        public void Save()
        {
            StreamWriter writer = new StreamWriter("JSON_Write.txt");
            string json = JsonConvert.SerializeObject(root);
            writer.Write(json); 
            writer.Close();
        }
    }
}
