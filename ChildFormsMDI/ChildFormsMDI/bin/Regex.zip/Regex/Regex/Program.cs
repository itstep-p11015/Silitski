﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ReGex
{
    class Program
    {
        static void Main(string[] args)
        {
            string code = @"using System; using System.Text.RegularExpressions; public class Example { public static void Main() { string pattern = ""\b[at]\w+""; string text = ""The threaded application ate up.""; MatchCollection matches; Regex defaultRegex = new Regex(pattern); matches = defaultRegex.Matches(text); Console.WriteLine(""Parsing '{0}'"", text); for (int ctr = 0; ctr < matches.Count; ctr++) Console.WriteLine(""{0}. {1}"", ctr, matches[ctr].Value); } }";
            string isInteger = @"\s(-?\d+)\s";
            string isFloat = @"\s(-?\d+[\.,]{1}\d+)\s";
            string isNameOfValue = @"\s+([_A-Za-z]\w+)\s*[=;]";
            string isOperation = @"\d+\s?([-+*/])\s?\d+";
            string change = @"(\s+)(-?\d+[.,]?\d*)(\s*)([-+*/])(\s*)(-?\d+[\.,]?\d*)(\s+)";
            string result = "";
            string isAssigned = @"([_A-Za-z]\w+)\s*(=)\s*((?("")"".*?""|.*?));\s";
            string text = "I'm a dog. 10 sdas 11.23,123 Mamaama -3,141592 * 2567863 DAAD 2.789 + 123 ABBA 2 string _1Ar1Ad = 1";
            MatchCollection matches;

            Regex defaultRegex = new Regex(isAssigned);
            matches = defaultRegex.Matches(code);
            //string[] substrings = defaultRegex.Split(text);
            Console.WriteLine("Parsing '{0}' with {1}", code, isAssigned);
            // Iterate matches
            
            //for (int i = 0; i < substrings.Length; i++)
            //{
            //    if (substrings[i].Equals("+") || substrings[i].Equals("-") || substrings[i].Equals("*") || substrings[i].Equals("/"))
            //    {
            //        string temp = substrings[i - 2];
            //        substrings[i - 2] = substrings[i + 2];
            //        substrings[i + 2] = temp;
            //    }
            //}
            //foreach (string str in substrings)
            //    result += str;
            //Console.WriteLine(result);
            
            Console.WriteLine("Name of value\tValue");
            for (int ctr = 0; ctr < matches.Count; ctr++)
                Console.WriteLine("{0}\t\t{1}", matches[ctr].Groups[1].Value, matches[ctr].Groups[3].Value);
            //for (int ctr = 0; ctr < matches.Count; ctr++)
            //for (int ctr = 0; ctr < matches.Count; ctr++)
            //    Console.WriteLine("{0}{1}{2}{3}{4}", matches[ctr].Groups[1].Value, matches[ctr].Groups[4].Value, matches[ctr].Groups[3].Value, matches[ctr].Groups[2].Value, matches[ctr].Groups[5].Value);
               
        }
    }
}
