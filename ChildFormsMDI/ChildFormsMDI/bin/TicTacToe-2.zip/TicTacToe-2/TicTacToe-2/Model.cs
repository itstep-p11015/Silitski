﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_2
{
    public enum Side
    {
        undefined, X, O, Draw
    }
    class Model
    {
        public class InvalidMoveException : InvalidOperationException
        {
            public InvalidMoveException(string msg)
                : base(msg)
            {

            }
        }
        Side[,] field = new Side[3, 3];
        Side turn = Side.X;
        Side winner = Side.undefined;

        public Side Turn
        {
            get
            {
                return turn;
            }
            set
            {
                turn = value;
            }
        }
        public Side Winner
        {
            get
            {
                return winner;
            }
        }

        public Model()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    field[i, j] = Side.undefined;
                }
            }
        }

        public void MakeMove(Side side, int i, int j)
        { 
            // проверяем выигрыш
            if (winner != Side.undefined || winner == Side.Draw)
            {
                throw new InvalidMoveException("Игра закончена!");
            }
            
            // проверяем чей ход
            if (side != turn)
            {
                throw new InvalidMoveException("Не твоя очередь!");
            }
            // проверяем не занята ли клетка
            if (field[i,j] != Side.undefined)
            {
                throw new InvalidMoveException("ignore");
            }
           
            // координаты не попали по полю
            if (i > 2 || i < 0 || j > 2 || j < 0)
            {
                throw new InvalidMoveException("Неправильная координата");
            }
            field[i,j] = side;

            if(CheckWinner())
            {
                winner = turn;
            }
            else
            {
                // проверяем ничью
                if (winner == Side.undefined && AllCellsFilled())
                {
                    winner = Side.Draw;
                }
                return;
            }
        }

        private bool AllCellsFilled()
        {
            foreach(Side cell in field)
            {
                if (cell == Side.undefined)
                    return false;
            }
            return true;
        }

        private bool CheckWinner()
        {
            if ((field[1, 1] == field[0, 0] && field[2, 2] == field[0, 0]) || (field[2, 0] == field[1, 1] && field[0, 2] == field[1, 1]))
            {
                winner = field[1, 1];
            }
            for (int i = 0; i < 3; i++)
            {
                if (field[1, i] == field[0, i] && field[2, i] == field[0, i]) 
                {
                    winner = field[0, i];
                }
            }
            for (int i = 0; i < 3; i++)
            {
                if (field[i, 1] == field[i, 0] && field[i, 2] == field[i, 0])
                {
                    winner = field[i, 0];
                }
            }
            return (winner != Side.undefined) ? true : false;
        }
    }
}
