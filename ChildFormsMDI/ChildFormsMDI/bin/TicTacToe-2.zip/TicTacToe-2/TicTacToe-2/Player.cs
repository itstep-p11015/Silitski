﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe_2
{
    abstract class Player
    {
        public Side side;
        public Model game;
        public string name;
        public Presenter p;
        abstract public void AskForMove();
    }
}
