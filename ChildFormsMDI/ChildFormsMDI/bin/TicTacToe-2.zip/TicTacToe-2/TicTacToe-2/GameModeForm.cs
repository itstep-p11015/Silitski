﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_2
{
    public partial class GameModeForm : Form
    {
        public MainForm main;
        public GameModeForm(MainForm main)
        {
            InitializeComponent();
            this.main = main;
        }

        public void OnePlayer(object sender, EventArgs e)
        {
            DifficultyForm DF = new DifficultyForm(main);
            DF.Show();
            this.Hide();
        }
        public void TwoPlayers(object sender, EventArgs e)
        {
            TwoNamesForm TNF = new TwoNamesForm(main);
            TNF.Show();
            this.Hide();
            
        }
    }
}
