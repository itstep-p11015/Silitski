﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe_2
{
    class RandomAIPlayer : Player
    {
        static Random r = new Random();
        readonly Form1 form;


        public RandomAIPlayer()
        {
        }
        public override void AskForMove()
        {
            p.tryMove(side, r.Next(0, 3), r.Next(0, 3));
        }
    }
}
