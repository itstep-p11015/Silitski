﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe_2
{
    class PriorityAIPlayer : Player
    {
        static Random r = new Random();
        readonly Form1 form;
        int[,] priority = { { 2, 3, 2 }, { 3, 1, 3 }, { 2, 3, 2 } };
        int[,] randCell = { { 0, 0 }, { 0, 1 }, { 0, 2 }, { 1, 0 }, { 1, 1 }, { 1, 2 }, { 2, 0 }, { 2, 1 }, { 2, 2 } };

        public PriorityAIPlayer()
        {
        }
        public override void AskForMove()
        {
            List<int> rand = new List<int>();
            for (int prior = 1; prior < 4; prior++)
            {
                rand = SetRandomArray();
                for (int k = 0; k < 9; k++)
                {
                    int i = randCell[rand[k], 0];
                    int j = randCell[rand[k], 1];
                    if (priority[i, j] == prior)
                    {
                        if (p.tryMove(side, i, j))
                            return;
                        else
                            continue;
                    }
                }
            }
        }
        private List<int> SetRandomArray()
        {
            Random random = new Random();
            List<int> shuffle = new List<int>();
            for (int i = 0; shuffle.Count < 9; i++)
            {
                int r = random.Next(9);
                if (shuffle.Contains(r))
                    continue;
                else
                    shuffle.Add(r);
            }
            return shuffle;
        }
    }
}
