﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_2
{
    public partial class DifficultyForm : Form
    {
        public int difficulty;
        public MainForm main;
        public DifficultyForm(MainForm main)
        {
            InitializeComponent();
            this.main = main;
        }

        public void EasyMode(object sender, EventArgs e)
        {
            NameForm NF = new NameForm(1, main);
            NF.Show();
            this.Hide();
        }
        public void MediumMode(object sender, EventArgs e)
        {
            NameForm NF = new NameForm(2, main);
            NF.Show();
            this.Hide();
        }
        public void HardMode(object sender, EventArgs e)
        {
            NameForm NF = new NameForm(3, main);
            NF.Show();
            this.Hide();
        }
    }
}
