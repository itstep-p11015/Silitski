﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_2
{
    class Presenter
    {
        Form1 form;
        public Model game;
        Player X, O;
        public Presenter(Form1 form, Player X, Player O)
        {
            this.form = form;
            game = new Model();

            this.X = X;
            this.O = O;

            this.O.side = Side.O;
            this.X.side = Side.X;

            this.X.game = this.game;
            this.O.game = this.game;

            this.X.p = this;
            this.O.p = this;

            nextMove();
        }

        private void nextMove()
        {
            if (game.Turn == Side.X || game.Turn == Side.undefined)
                X.AskForMove();
            else
                O.AskForMove();
        }

        public bool tryMove(Side s, int i, int j)
        {
            bool success = false;
            try
            {
                game.MakeMove(s, i, j);
                form.buttons[i, j].Image = (game.Turn == Side.X) ? TicTacToe_2.Properties.Resources.cross : TicTacToe_2.Properties.Resources.toe;
                form.Refresh();
                if (game.Winner != Side.undefined)
                    game.Turn = Side.undefined;
                else
                    game.Turn = (game.Turn == Side.X) ? Side.O : Side.X;
                success = true;
                if (game.Winner == Side.Draw)
                    MessageBox.Show("Ничья!");
                if (game.Winner != Side.undefined && game.Winner != Side.Draw)
                    MessageBox.Show("Поздравляю " + ((game.Winner == Side.X) ? X.name : O.name) + ", ты победил!");
            }
            catch (Model.InvalidMoveException ex)
            {
                if (ex.Message == "ignore")
                    return success;
                else
                {
                    Player p = (game.Turn == Side.X) ? X : O;
                    // если игрок - человек
                    if (p is HumanPlayer)
                    {
                        // ругаем
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            if (game.Winner == Side.undefined)
                nextMove();
            return success;
        }
    }
}
