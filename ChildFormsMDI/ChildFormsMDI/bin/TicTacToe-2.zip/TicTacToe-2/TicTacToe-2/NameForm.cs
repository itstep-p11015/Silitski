﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_2
{

    public partial class NameForm : Form
    {
        public MainForm main;
        public int difficulty;
        public string name;
        public NameForm(int difficulty, MainForm main)
        {
            InitializeComponent();
            this.difficulty = difficulty;
            this.main = main;
        }

        public void StartGame(object sender, EventArgs e)
        {
            name = this.textBox1.Text;
            Form1 form = new Form1();
            form.starter = main;
            form.SetPlayers(this.name, this.difficulty);
            form.Show();
            this.Hide();
        }
    }
}
