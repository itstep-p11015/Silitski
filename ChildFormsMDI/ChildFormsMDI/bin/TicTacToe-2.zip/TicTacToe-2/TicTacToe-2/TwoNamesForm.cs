﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_2
{
    public partial class TwoNamesForm : Form
    {
        public MainForm main;
        public string name1;
        public string name2;
        public TwoNamesForm(MainForm main)
        {
            InitializeComponent();
            this.main = main;
        }

        public void StartGame(object sender, EventArgs e)
        {
            name1 = this.textBox1.Text;
            name2 = this.textBox2.Text;
            Form1 form = new Form1();
            form.starter = main;
            form.SetPlayers(name1, name2);
            form.Show();
            this.Hide();
        }
    }
}
