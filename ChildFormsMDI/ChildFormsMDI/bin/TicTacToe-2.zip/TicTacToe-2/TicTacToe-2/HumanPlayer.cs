﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe_2
{
    class HumanPlayer:Player
    {
        readonly Form1 form;
        public HumanPlayer(Form1 form, string name)
        {
            this.form = form;
            this.name = name;
        }
        public override void AskForMove()
        {
            form.turn = side;
        }
    }
}
