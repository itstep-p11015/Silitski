﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe_2
{
    
    public partial class Form1 : Form
    {
        const int picSize = 99;

        Player playerX, playerO;
        public MainForm starter;

        public PictureBox[,] buttons = new PictureBox[3, 3];

        Presenter referee;

        public struct Point
        {
            public int x, y;
        }

        public Form1()
        {
            this.BackgroundImage = TicTacToe_2.Properties.Resources.table2;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    InitializeComponent();

                    PictureBox a = new PictureBox();
                    //a.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                    a.Location = new System.Drawing.Point(i * picSize + (7 * i), j * picSize + (7 * j));
                    a.Size = new System.Drawing.Size(picSize, picSize);
                    a.SizeMode = PictureBoxSizeMode.CenterImage;
                    a.BackColor = Color.White;
                    
                    //a.TabStop = false;
                    //a.Text = "";
                    //a.UseVisualStyleBackColor = true;
                    a.Tag = new Point { x = i, y = j };
                    
                    a.Click += cellClick;

                    this.Controls.Add(a);

                    buttons[i, j] = a;
                }
            }
        }

        public void SetPlayers(string name1, string name2)
        {
            playerX = new HumanPlayer(this, name1);
            playerO = new HumanPlayer(this, name2);
            referee = new Presenter(this, playerX, playerO);
        }
        public void SetPlayers(string name, int difficulty)
        {
            switch(difficulty)
            {
                case 1:
                    playerX = new RandomAIPlayer();
                    playerO = new HumanPlayer(this, name);
                    break;
                case 2:
                    playerX = new PriorityAIPlayer();
                    playerO = new HumanPlayer(this, name);
                    break;
                case 3:
                    MessageBox.Show("К сожалению, этот уровень пока недоступен.");
                    break;
            }
            referee = new Presenter(this, playerX, playerO);
        }

        public void showMessage(string msg)
        {
            MessageBox.Show(msg);
        }

        public Side turn = Side.undefined;

        void cellClick(object sender, EventArgs e)
        {
            Point pos = (Point)((PictureBox)sender).Tag;

            referee.tryMove(turn, pos.x, pos.y);
        }

        

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            starter.Show();
        }
    }
}
